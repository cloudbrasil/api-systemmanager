import _ from 'lodash';
import Boom from '@hapi/boom';
import Joi from 'joi';

/**
 * Class for user registration in a user
 * @class
 */
class Help {

  constructor(options) {
    Joi.assert(options, Joi.object().required());
    Joi.assert(options.parent, Joi.object().required());

    const self = this;
    self.parent = options.parent;
    self._client = self.parent.dispatch.getClient();
  }

  /**
   * @author Augusto Pissarra <abernardo.br@gmail.com>
   * @description Get the return data and check for errors
   * @param {object} retData Response HTTP
   * @return {*}
   * @private
   */
  _returnData(retData, def = {}) {
    if (retData.status !== 200) {
      return Boom.badRequest(_.get(retData, 'message', 'No error message reported!'))
    } else {
      return _.get(retData, 'data', def);
    }
  }

  /**
   * @author Myndware <augusto.pissarra@myndware.com>
   * @description Set header with new session
   * @param {string} session Session, token JWT
   * @return {object} header with new session
   * @private
   */
  _setHeader(session) {
    return {
      headers: {
        Authorization: session,
      }
    };
  }

  /**
   * @author Augusto Pissarra <abernardo.br@gmail.com>
   * @description get help topics for a user. Either by organizaiton product or by supplied filter. But always only the user language.
   * @param {object} filter a filter to apply. if empty, null or undefined, than we will bring the help topics by organizaiton product.
   * @param {string} session JWT token
   * @public
   * @async
   * @example
   *
   * const API = require('@docbrasil/api-systemmanager');
   * const api = new API();
   * const session = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';
   * await api.user.help.getTopics({}, session);
   */
  async getTopics(filter = {}, session) {
    const self = this;

    try {
      Joi.assert(session, Joi.string().required(), 'SM session (JWT) to call API');
      let query = '';
      if(!_.isEmpty(filter)) {
        const queryFilter = JSON.stringify(filter);
        query = `?filter=${queryFilter.toString('base64')}`;
      }
      const apiCall = self._client.get(`/help/topics${query}`, self._setHeader(session));
      return self._returnData(await apiCall);
    } catch (ex) {
      throw ex;
    }
  }

  /**
   * @author Myndware <augusto.pissarra@myndware.com>
   * @description Method to find helps from a topic
   * @param {object} params Params to get helps from topic
   * @param {object} params.id Topic id (_id database)
   * @param {string} session Session, token JWT
   * @returns {promise}
   * @public
   * @example
   *
   * const API = require('@docbrasil/api-systemmanager');
   * const api = new API();
   * const params = {
   *  id: '5dadd01dc4af3941d42f8c5c'
   * };
   * const session = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';
   * await api.user.help.get(params, session);
   */
  async get(params, session) {
    const self = this;

    try {
      Joi.assert(params, Joi.object().required(), 'Params to helps from a topic');
      Joi.assert(params.id, Joi.string().required(), 'Topic id (_id database)');
      Joi.assert(session, Joi.string().required(), 'Session token JWT');

      const {id} = params;
      const apiCall = self._client.get(`/help/topic/${id}`, self._setHeader(session));

      return self._returnData(await apiCall);
    } catch (ex) {
      throw ex;
    }
  }

  /**
   * @author Myndware <augusto.pissarra@myndware.com>
   * @description Get list of external URL help pages available for the logged user.
   * Returns help pages where the user has permission based on their groups or user ID.
   * @param {string} session Session, token JWT
   * @returns {promise<Array>} Array of external URL help pages with permissions
   * @public
   * @example
   *
   * const API = require('@docbrasil/api-systemmanager');
   * const api = new API();
   * const session = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';
   * const externalUrls = await api.user.help.listExternalUrls(session);
   * // Returns:
   * // [
   * //   {
   * //     _id: '...',
   * //     title: 'Help Page Title',
   * //     permissions: ['VIEW', 'CREATE_EXTERNAL_URL'],
   * //     showPoweredBy: true,
   * //     showCreatedBy: false
   * //   }
   * // ]
   */
  async listExternalUrls(session) {
    const self = this;

    try {
      Joi.assert(session, Joi.string().required(), 'Session token JWT');

      const apiCall = self._client.get('/help/external-urls', self._setHeader(session));
      return self._returnData(await apiCall, []);
    } catch (ex) {
      throw ex;
    }
  }

  /**
   * @author Myndware <augusto.pissarra@myndware.com>
   * @description Update a schedule associated with a help page.
   * Allows partial updates (e.g., just the cron expression).
   * @param {object} params Params for update
   * @param {string} params.id Schedule id (_id database)
   * @param {object} params.data Partial update data (e.g., { schedule: { cron: '0 9 * * *' } })
   * @param {string} session Session, token JWT
   * @returns {promise<object>} Updated schedule document
   * @public
   * @example
   *
   * const API = require('@docbrasil/api-systemmanager');
   * const api = new API();
   * const params = {
   *   id: '5dadd01dc4af3941d42f8c5c',
   *   data: {
   *     schedule: { cron: '0 9 * * *' }
   *   }
   * };
   * const session = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';
   * await api.user.help.updateSchedule(params, session);
   */
  async updateSchedule(params, session) {
    const self = this;

    try {
      Joi.assert(params, Joi.object().required(), 'Params to update schedule');
      Joi.assert(params.id, Joi.string().required(), 'Schedule id (_id database)');
      Joi.assert(params.data, Joi.object().required(), 'Data to update');
      Joi.assert(session, Joi.string().required(), 'Session token JWT');

      const { id, data } = params;
      const apiCall = self._client.put(`/help/schedule/${id}`, data, self._setHeader(session));

      return self._returnData(await apiCall);
    } catch (ex) {
      throw ex;
    }
  }

}

export default Help;
